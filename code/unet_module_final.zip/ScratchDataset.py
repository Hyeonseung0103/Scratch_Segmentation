import torch
from PIL import Image
import os
import numpy as np
from torch.utils.data import Dataset
# 데이터 로더 구현
class ScratchDataset(torch.utils.data.Dataset):
    def __init__(self, data_dir, data_type, transform = None):
        self.data_dir = data_dir
        self.transform = transform
        self.data_type = data_type
        lst_data = os.listdir(self.data_dir)
        
        lst_label = [f for f in lst_data if f.startswith(f'{data_type}_label')]
        lst_input = [f for f in lst_data if f.startswith(f'{data_type}_input')]
        
        lst_label.sort()
        lst_input.sort()
        
        self.lst_label = lst_label
        self.lst_input = lst_input
        
    
    def __len__(self):
        return len(self.lst_label)
    
    def __getitem__(self,index):
        label = Image.open(os.path.join(self.data_dir, self.lst_label[index]))
        input = Image.open(os.path.join(self.data_dir, self.lst_input[index])).convert('L')        
        #정규화
        label = np.array(label) / 255.0 # 0과 1만 남도록 라벨링
        input = np.array(input) / 255.0 # 0과 1 사이로 정규화
        
        #이미디와 레이블의 차원이 2일 경우(만약 채널이 없으면 흑백 이미지) 새로운 채널을 생성
        # 3차원이 RGB로 된 컬러 차원이라서? 이건 잘 모르겠음.
        if label.ndim == 2:
            label = label[:, :, np.newaxis]
        if input.ndim == 2:
            input = input[:, :, np.newaxis]
        
        data = {'input': input, 'label': label}
        
        # transform이 정의되어 있다면 transform을 거친 데이터를 불러옴
        if self.transform:
            data = self.transform(data)
        
        return data     
        
        